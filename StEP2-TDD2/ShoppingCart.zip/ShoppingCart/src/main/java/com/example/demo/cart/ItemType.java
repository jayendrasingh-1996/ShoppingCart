package com.example.demo.cart;

public enum ItemType {

	SOAP,DEO,PERFUME;
}
